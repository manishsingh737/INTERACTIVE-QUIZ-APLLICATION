
const questions = [
  {
    question: "Which of the following are programming languages?",
    options: ["HTML", "Python", "CSS", "Java"],
    answer: ["Python", "Java"]
  },
  {
    question: "Which tools are used for version control?",
    options: ["Git", "Figma", "GitHub", "Postman"],
    answer: ["Git", "GitHub"]
  },
  {
    question: "Which are valid data types in JavaScript?",
    options: ["Boolean", "String", "MySQL", "Number"],
    answer: ["Boolean", "String", "Number"]
  },
  {
    question: "Which are frontend frameworks/libraries?",
    options: ["React", "Vue", "Node.js", "Angular"],
    answer: ["React", "Vue", "Angular"]
  },
  {
    question: "Which protocols are used in the internet?",
    options: ["HTTP", "FTP", "SMTP", "HTML"],
    answer: ["HTTP", "FTP", "SMTP"]
  }
];

let currentQuestion = 0;
let score = 0;
let feedbackGiven = false;

const questionEl = document.getElementById('question');
const optionsEl = document.getElementById('options');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');

function loadQuestion() {
  const q = questions[currentQuestion];
  questionEl.textContent = q.question;
  optionsEl.innerHTML = "";
  feedbackGiven = false;
  nextBtn.textContent = "Check Answer";

  q.options.forEach((option, i) => {
    const li = document.createElement("li");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.id = "opt" + i;
    checkbox.value = option;

    const label = document.createElement("label");
    label.htmlFor = "opt" + i;
    label.textContent = option;

    li.appendChild(checkbox);
    li.appendChild(label);
    optionsEl.appendChild(li);
  });
}

function getSelectedOptions() {
  return Array.from(document.querySelectorAll("input[type='checkbox']:checked"))
              .map(cb => cb.value);
}

function showFeedback() {
  const correctAnswers = questions[currentQuestion].answer;
  const selected = getSelectedOptions();
  const lis = document.querySelectorAll("#options li");

  let isCorrect = selected.length === correctAnswers.length &&
                  selected.every(opt => correctAnswers.includes(opt));

  lis.forEach(li => {
    const input = li.querySelector("input");
    const label = li.querySelector("label");
    const val = input.value;
    input.disabled = true;

    if (input.checked && correctAnswers.includes(val)) {
      li.classList.add("correct");
      label.innerHTML += " ✅ <b>- Right Answer</b>";
    } else if (input.checked && !correctAnswers.includes(val)) {
      li.classList.add("wrong");
      label.innerHTML += " ❌ <b>- Wrong Answer</b>";
    } else if (!input.checked && correctAnswers.includes(val)) {
      li.classList.add("correct");
      label.innerHTML += " ⚠️ <b>- You missed this correct answer</b>";
    }
  });

  if (isCorrect) score++;
}

nextBtn.addEventListener("click", () => {
  const selected = getSelectedOptions();

  if (!feedbackGiven) {
    if (selected.length === 0) {
      alert("Please select at least one option.");
      return;
    }
    showFeedback();
    feedbackGiven = true;
    nextBtn.textContent = "Next Question";
  } else {
    currentQuestion++;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showScore();
    }
  }
});

function showScore() {
  questionEl.textContent = "Quiz Completed!";
  optionsEl.innerHTML = "";
  nextBtn.style.display = "none";
  scoreContainer.innerHTML = `<h2>Your Score: ${score} / ${questions.length}</h2>`;
}

loadQuestion();
